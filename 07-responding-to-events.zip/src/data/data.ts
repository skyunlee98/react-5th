


export const avatarData = [
  {id:'avatar-1',name:'짱구',status:'offline'},
  {id:'avatar-2',name:'맹구',status:'online'},
  {id:'avatar-3',name:'철수',status:'dont-disturb'},
  {id:'avatar-4',name:'유리',status:'away'},
  {id:'avatar-4',name:'훈이',status:'online'},
]