import { statusMessage } from "@/data/learn"
import DataBinding from "./DataBinding"

function JSX_Markup() {
  return (
    <dl className="descriptionList">
      <DataBinding statusMessage={statusMessage} />
    </dl>
  )
}
export default JSX_Markup


// dl, dt, dd